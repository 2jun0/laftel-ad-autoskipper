# 라프텔 광고 스키퍼

라프텔 광고를 자동으로 스킵하는 크롬 확장프로그램 입니다(애드블록이 아님)

본 프로그램은 [yt-ad-autoskipper](https://github.com/squgeim/yt-ad-autoskipper)를 기반으로 만들어졌습니다.

## 기능
- 광고 자동 스킵 기능(Skip ad 버튼을 자동으로 누릅니다)
- 광고 음소거 기능(설정창에서 on/off)

## 다운로드
[크롬 앱스토어](https://chrome.google.com/webstore/detail/라프텔-광고-스키퍼/dcpckjplmdcgdbapaepejenmkknkoimg)